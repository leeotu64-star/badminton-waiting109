// Vercel Serverless API
// 저장소: Vercel Marketplace의 Redis 연결 필요
const KEY="jangunbong:wait:v2";
const defaults=()=>({list:[],locks:{1:false,2:false,3:false,4:false,5:false},maxLimit:5});

async function redis(command,args=[]){
 const url=process.env.UPSTASH_REDIS_REST_URL;
 const token=process.env.UPSTASH_REDIS_REST_TOKEN;
 if(!url||!token) throw new Error("Redis가 연결되지 않았습니다. Vercel Marketplace에서 Redis를 연결하세요.");
 const r=await fetch(url,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify([command,...args])});
 const d=await r.json();
 if(!r.ok||d.error)throw new Error(d.error||"Redis 오류");
 return d.result;
}
async function getState(){const raw=await redis("GET",[KEY]);if(!raw)return defaults();try{return JSON.parse(raw)}catch{return defaults()}}
async function setState(s){await redis("SET",[KEY,JSON.stringify(s)])}
function out(x,status=200){return new Response(JSON.stringify(x),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}})}
export default async function handler(req){
 try{
  let s=await getState();
  if(req.method==="GET")return out(s);
  if(req.method!=="POST")return out({error:"GET/POST만 허용됩니다."},405);
  const b=await req.json(),a=b.action;
  if(a==="add"){
   const c=+b.court,n=String(b.nickname||"").trim(),g=String(b.gameType||"").trim();
   if(c<1||c>5)return out({error:"코트 번호 오류"},400);
   if(!n)return out({error:"닉네임을 입력하세요."},400);
   if(s.locks[c])return out({error:"현재 대기가 잠겨 있습니다."},409);
   const w=s.list.filter(x=>+x.court===c&&x.status==="WAITING");
   if(w.length>=s.maxLimit)return out({error:`최대 ${s.maxLimit}명입니다.`},409);
   const item={id:crypto.randomUUID(),nickname:n,gameType:g,court:c,registered_at:new Date().toISOString(),status:"WAITING"};
   s.list.push(item);await setState(s);
   return out({ok:true,item:{...item,position:w.length+1}},201);
  }
  if(a==="complete"||a==="clear"||a==="delete"){
   if(b.id){let x=s.list.find(x=>x.id===b.id);if(!x)return out({error:"대기자를 찾을 수 없습니다."},404);x.status=a==="complete"?"COMPLETED":"DELETED"}
   else {let c=+b.court;s.list.forEach(x=>{if(+x.court===c&&x.status==="WAITING")x.status=a==="complete"?"COMPLETED":"DELETED"})}
   await setState(s);return out({ok:true});
  }
  if(a==="lock"){let c=+b.court;if(c<1||c>5)return out({error:"코트 오류"},400);s.locks[c]=!s.locks[c];await setState(s);return out({ok:true,locked:s.locks[c]})}
  if(a==="setLimit"){let n=+b.maxLimit;if(!Number.isInteger(n)||n<1||n>50)return out({error:"최대인원은 1~50"},400);s.maxLimit=n;await setState(s);return out({ok:true})}
  return out({error:"알 수 없는 action"},400);
 }catch(e){console.error(e);return out({error:e.message},500)}
}